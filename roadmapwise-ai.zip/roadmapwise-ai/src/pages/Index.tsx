import { useState, useEffect } from "react"
import { ThemeProvider } from "@/components/ui/theme-provider"
import { Header } from "@/components/Header"
import { Dashboard } from "@/components/Dashboard"
import { RoadmapGenerator } from "@/components/RoadmapGenerator"
import { RoadmapView } from "@/components/RoadmapView"
import { Achievements } from "@/components/Achievements"
import { Profile } from "@/components/Profile"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookOpen, Plus, Star, Flame, Target, Trophy } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const Index = () => {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("dashboard")
  const [selectedRoadmap, setSelectedRoadmap] = useState<string | null>(null)
  const [showGenerator, setShowGenerator] = useState(false)

  // Mock user data - in real app this would come from your backend
  const [userStats, setUserStats] = useState({
    streak: 15,
    totalCompleted: 45,
    level: 8,
    experiencePoints: 2340,
    activeLearningDays: [1, 5, 8, 12, 15, 18, 22, 25, 28, 30, 35, 40, 42, 45], // Days of year with activity
    weeklyGoal: 10,
    weeklyProgress: 7,
    roadmapsCompleted: 2,
    totalStudyTime: 65,
    problemsSolved: {
      easy: 78,
      medium: 45,
      hard: 12,
      total: 135
    },
    globalRanking: 143811,
    attendedContests: 15
  })

  const [userProfile, setUserProfile] = useState({
    name: "Alex Johnson",
    email: "alex@example.com", 
    bio: "Passionate learner exploring AI, web development, and design. Always looking to grow and take on new challenges.",
    location: "San Francisco, CA",
    githubUsername: "alexjohnson",
    twitterUsername: "alexjohnson",
    joinDate: "January 2024",
    rank: 96394,
    learningGoals: ["Master React", "Learn AI/ML", "Improve Design Skills", "System Design"],
    preferences: {
      emailNotifications: true,
      weeklyDigest: true,
      achievementAlerts: true
    }
  })

  const [achievements] = useState([
    { 
      id: 1, 
      title: "First Steps", 
      description: "Complete your first task", 
      icon: Star, 
      earned: true, 
      earnedDate: "Jan 15, 2024",
      category: 'completion' as const
    },
    { 
      id: 2, 
      title: "Week Warrior", 
      description: "7-day learning streak", 
      icon: Flame, 
      earned: true, 
      earnedDate: "Jan 22, 2024",
      category: 'streak' as const
    },
    { 
      id: 3, 
      title: "Module Master", 
      description: "Complete 5 modules", 
      icon: Target, 
      earned: true, 
      earnedDate: "Feb 1, 2024",
      category: 'completion' as const
    },
    { 
      id: 4, 
      title: "Road Runner", 
      description: "Complete a full roadmap", 
      icon: Trophy, 
      earned: true, 
      earnedDate: "Feb 10, 2024",
      category: 'special' as const
    },
  ])

  const [apiKeys, setApiKeys] = useState({
    openai: "",
    gemini: "",
    perplexity: ""
  })

  const [roadmaps, setRoadmaps] = useState([
    {
      id: "1",
      title: "Full-Stack Web Development",
      description: "Comprehensive path to becoming a full-stack developer",
      difficulty: "intermediate",
      aiProvider: "openai",
      estimatedDuration: "12-16 weeks",
      progress: 65,
      modules: [
        {
          id: "1",
          title: "Frontend Fundamentals",
          description: "HTML, CSS, and JavaScript basics",
          completed: true,
          tasks: [
            { id: "1-1", title: "HTML Structure & Semantics", completed: true, resources: ["MDN Docs", "Practice"] },
            { id: "1-2", title: "CSS Styling & Layouts", completed: true, resources: ["CSS Grid Guide"] },
            { id: "1-3", title: "JavaScript Fundamentals", completed: true, resources: ["JS Course"] }
          ]
        },
        {
          id: "2", 
          title: "React Development",
          description: "Building dynamic UIs with React",
          completed: false,
          tasks: [
            { id: "2-1", title: "React Components", completed: true, resources: ["React Docs"] },
            { id: "2-2", title: "State Management", completed: false, resources: ["Redux Tutorial"] },
            { id: "2-3", title: "React Hooks", completed: false, resources: ["Hooks Guide"] }
          ]
        }
      ],
      createdAt: "2024-01-15T10:00:00Z"
    }
  ])

  // Load data from localStorage on mount
  useEffect(() => {
    const savedApiKeys = localStorage.getItem('ai-roadmap-api-keys')
    const savedRoadmaps = localStorage.getItem('ai-roadmap-roadmaps')
    const savedProfile = localStorage.getItem('ai-roadmap-profile')
    const savedStats = localStorage.getItem('ai-roadmap-stats')

    if (savedApiKeys) setApiKeys(JSON.parse(savedApiKeys))
    if (savedRoadmaps) setRoadmaps(JSON.parse(savedRoadmaps))
    if (savedProfile) setUserProfile(JSON.parse(savedProfile))
    if (savedStats) setUserStats(JSON.parse(savedStats))
  }, [])

  // Save to localStorage when data changes
  useEffect(() => {
    localStorage.setItem('ai-roadmap-api-keys', JSON.stringify(apiKeys))
  }, [apiKeys])

  useEffect(() => {
    localStorage.setItem('ai-roadmap-roadmaps', JSON.stringify(roadmaps))
  }, [roadmaps])

  useEffect(() => {
    localStorage.setItem('ai-roadmap-profile', JSON.stringify(userProfile))
  }, [userProfile])

  useEffect(() => {
    localStorage.setItem('ai-roadmap-stats', JSON.stringify(userStats))
  }, [userStats])

  const handleRoadmapGenerated = (newRoadmap: any) => {
    setRoadmaps(prev => [newRoadmap, ...prev])
    setShowGenerator(false)
    setActiveTab("roadmaps")
    toast({
      title: "Roadmap Generated! 🎉",
      description: `Your "${newRoadmap.title}" roadmap is ready to start.`,
    })
  }

  const handleTaskComplete = (roadmapId: string, moduleId: string, taskId: string) => {
    setRoadmaps(prev => prev.map(roadmap => {
      if (roadmap.id === roadmapId) {
        const updatedModules = roadmap.modules.map(module => {
          if (module.id === moduleId) {
            const updatedTasks = module.tasks.map(task => 
              task.id === taskId ? { ...task, completed: !task.completed } : task
            )
            return { ...module, tasks: updatedTasks }
          }
          return module
        })
        
        // Calculate progress
        const totalTasks = updatedModules.reduce((sum, m) => sum + m.tasks.length, 0)
        const completedTasks = updatedModules.reduce((sum, m) => 
          sum + m.tasks.filter(t => t.completed).length, 0
        )
        const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0
        
        return { ...roadmap, modules: updatedModules, progress }
      }
      return roadmap
    }))

    // Update user stats
    setUserStats(prev => ({
      ...prev,
      totalCompleted: prev.totalCompleted + 1,
      weeklyProgress: prev.weeklyProgress + 1
    }))

    toast({
      title: "Task Completed! ✅",
      description: "Great progress! Keep up the momentum.",
    })
  }

  const handleModuleComplete = (roadmapId: string, moduleId: string) => {
    setRoadmaps(prev => prev.map(roadmap => {
      if (roadmap.id === roadmapId) {
        const updatedModules = roadmap.modules.map(module => 
          module.id === moduleId ? { ...module, completed: true } : module
        )
        return { ...roadmap, modules: updatedModules }
      }
      return roadmap
    }))

    toast({
      title: "Module Completed! 🏆",
      description: "Excellent work! You've mastered this module.",
    })
  }

  const handleApiKeyUpdate = (provider: string, key: string) => {
    setApiKeys(prev => ({ ...prev, [provider]: key }))
    toast({
      title: "API Key Updated",
      description: `${provider.charAt(0).toUpperCase() + provider.slice(1)} API key has been saved.`,
    })
  }

  const handleProfileUpdate = (updatedProfile: any) => {
    setUserProfile(updatedProfile)
    toast({
      title: "Profile Updated",
      description: "Your profile has been saved successfully.",
    })
  }

  const renderContent = () => {
    if (selectedRoadmap) {
      const roadmap = roadmaps.find(r => r.id === selectedRoadmap)
      if (!roadmap) return null
      
      return (
        <RoadmapView
          roadmap={roadmap}
          onTaskComplete={(moduleId, taskId) => handleTaskComplete(selectedRoadmap, moduleId, taskId)}
          onModuleComplete={(moduleId) => handleModuleComplete(selectedRoadmap, moduleId)}
        />
      )
    }

    if (showGenerator) {
      return <RoadmapGenerator onRoadmapGenerated={handleRoadmapGenerated} />
    }

    switch (activeTab) {
      case "dashboard":
        return <Dashboard userStats={userStats} roadmaps={roadmaps} />
      
      case "roadmaps":
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">My Roadmaps</h2>
                <p className="text-muted-foreground">Manage your learning paths</p>
              </div>
              <Button onClick={() => setShowGenerator(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Generate New Roadmap
              </Button>
            </div>
            
            {roadmaps.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No roadmaps yet</h3>
                  <p className="text-muted-foreground mb-6">
                    Generate your first AI-powered learning roadmap to get started
                  </p>
                  <Button onClick={() => setShowGenerator(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Your First Roadmap
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {roadmaps.map(roadmap => (
                  <Card 
                    key={roadmap.id}
                    className="cursor-pointer hover:border-primary/50 transition-colors"
                    onClick={() => setSelectedRoadmap(roadmap.id)}
                  >
                    <CardHeader>
                      <CardTitle className="line-clamp-2">{roadmap.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {roadmap.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{Math.round(roadmap.progress)}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${roadmap.progress}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>{roadmap.modules.length} modules</span>
                          <span>{roadmap.estimatedDuration}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )
      
      case "achievements":
        return <Achievements userStats={userStats} />
      
      case "profile":
        return (
          <Profile
            userProfile={userProfile}
            userStats={userStats}
            achievements={achievements}
            apiKeys={apiKeys}
            onProfileUpdate={handleProfileUpdate}
            onApiKeyUpdate={handleApiKeyUpdate}
          />
        )
      
      default:
        return <Dashboard userStats={userStats} roadmaps={roadmaps} />
    }
  }

  return (
    <ThemeProvider defaultTheme="light" storageKey="ai-roadmap-theme">
      <div className="min-h-screen bg-background">
        <Header
          activeTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab)
            setSelectedRoadmap(null)
            setShowGenerator(false)
          }}
          userStats={userStats}
        />
        
        <main className="container mx-auto py-6">
          {selectedRoadmap && (
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={() => setSelectedRoadmap(null)}
                className="mb-4"
              >
                ← Back to Roadmaps
              </Button>
            </div>
          )}
          
          {renderContent()}
        </main>
      </div>
    </ThemeProvider>
  )
}

export default Index