import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, Sparkles, Brain, Globe, Code, Palette, TrendingUp } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface RoadmapGeneratorProps {
  onRoadmapGenerated: (roadmap: any) => void
}

export function RoadmapGenerator({ onRoadmapGenerated }: RoadmapGeneratorProps) {
  const [topic, setTopic] = useState("")
  const [description, setDescription] = useState("")
  const [difficulty, setDifficulty] = useState("intermediate")
  const [isGenerating, setIsGenerating] = useState(false)
  const [selectedAI, setSelectedAI] = useState<string | null>(null)

  const aiProviders = [
    {
      id: 'openai',
      name: 'OpenAI GPT-4',
      icon: Brain,
      description: 'Best for technical & programming topics',
      topics: ['Software Development', 'Data Structures', 'AI/ML', 'Cloud Computing', 'DevOps'],
      color: 'bg-primary text-primary-foreground'
    },
    {
      id: 'gemini',
      name: 'Google Gemini',
      icon: Palette,
      description: 'Best for creative & multimedia topics',
      topics: ['Design', 'Content Creation', 'Art', 'Video Editing', 'Photography'],
      color: 'bg-secondary text-secondary-foreground'
    },
    {
      id: 'perplexity',
      name: 'Perplexity AI',
      icon: Globe,
      description: 'Best for current trends & research',
      topics: ['Market Research', 'SEO', 'Latest Technologies', 'Business Trends'],
      color: 'bg-accent text-accent-foreground'
    }
  ]

  const handleTopicChange = (value: string) => {
    setTopic(value)
    
    // Auto-select AI based on topic
    const lowerTopic = value.toLowerCase()
    if (lowerTopic.includes('programming') || lowerTopic.includes('development') || 
        lowerTopic.includes('coding') || lowerTopic.includes('algorithm') ||
        lowerTopic.includes('data structure') || lowerTopic.includes('ai') ||
        lowerTopic.includes('machine learning') || lowerTopic.includes('cloud')) {
      setSelectedAI('openai')
    } else if (lowerTopic.includes('design') || lowerTopic.includes('creative') ||
               lowerTopic.includes('art') || lowerTopic.includes('video') ||
               lowerTopic.includes('photo') || lowerTopic.includes('ui/ux')) {
      setSelectedAI('gemini')
    } else if (lowerTopic.includes('research') || lowerTopic.includes('seo') ||
               lowerTopic.includes('marketing') || lowerTopic.includes('trend') ||
               lowerTopic.includes('business') || lowerTopic.includes('current')) {
      setSelectedAI('perplexity')
    } else {
      setSelectedAI(null)
    }
  }

  const generateRoadmap = async () => {
    if (!topic.trim()) return
    
    setIsGenerating(true)
    
    // Mock AI generation with realistic delay
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Generate mock roadmap based on topic
    const mockRoadmap = {
      id: Date.now().toString(),
      title: `${topic} Learning Path`,
      description: description || `Comprehensive roadmap for mastering ${topic}`,
      difficulty,
      aiProvider: selectedAI || 'openai',
      estimatedDuration: '8-12 weeks',
      modules: [
        {
          id: '1',
          title: 'Fundamentals & Setup',
          description: `Core concepts and environment setup for ${topic}`,
          tasks: [
            { id: '1-1', title: 'Understand basic concepts', completed: false, resources: ['Article', 'Video'] },
            { id: '1-2', title: 'Set up development environment', completed: false, resources: ['Documentation'] },
            { id: '1-3', title: 'First hands-on exercise', completed: false, resources: ['Practice'] }
          ],
          completed: false
        },
        {
          id: '2',
          title: 'Core Learning',
          description: `Deep dive into ${topic} fundamentals`,
          tasks: [
            { id: '2-1', title: 'Advanced concepts', completed: false, resources: ['Course', 'Book'] },
            { id: '2-2', title: 'Practical exercises', completed: false, resources: ['Exercises'] },
            { id: '2-3', title: 'Build first project', completed: false, resources: ['Project Guide'] }
          ],
          completed: false
        },
        {
          id: '3',
          title: 'Advanced Topics',
          description: `Master advanced ${topic} techniques`,
          tasks: [
            { id: '3-1', title: 'Advanced patterns', completed: false, resources: ['Advanced Tutorial'] },
            { id: '3-2', title: 'Optimization techniques', completed: false, resources: ['Documentation'] },
            { id: '3-3', title: 'Industry best practices', completed: false, resources: ['Industry Guide'] }
          ],
          completed: false
        },
        {
          id: '4',
          title: 'Final Project',
          description: `Capstone project to demonstrate ${topic} mastery`,
          tasks: [
            { id: '4-1', title: 'Plan final project', completed: false, resources: ['Planning Template'] },
            { id: '4-2', title: 'Implement project', completed: false, resources: ['Implementation Guide'] },
            { id: '4-3', title: 'Deploy and showcase', completed: false, resources: ['Deployment Guide'] }
          ],
          completed: false
        }
      ],
      createdAt: new Date().toISOString(),
      progress: 0
    }
    
    onRoadmapGenerated(mockRoadmap)
    setIsGenerating(false)
    setTopic("")
    setDescription("")
  }

  const quickTopics = [
    'Full-Stack Web Development',
    'Data Structures & Algorithms',
    'Machine Learning',
    'UI/UX Design',
    'Digital Marketing',
    'Cloud Computing',
    'Mobile App Development',
    'DevOps Engineering'
  ]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <span>Generate AI Learning Roadmap</span>
          </CardTitle>
          <CardDescription>
            Enter a topic and let AI create a personalized learning path for you
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Learning Topic</label>
              <Input
                placeholder="e.g., Full-Stack Web Development, Machine Learning, UI/UX Design..."
                value={topic}
                onChange={(e) => handleTopicChange(e.target.value)}
                className="w-full"
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {quickTopics.map((quickTopic) => (
                <Button
                  key={quickTopic}
                  variant="outline"
                  size="sm"
                  onClick={() => handleTopicChange(quickTopic)}
                  className="text-xs h-8"
                >
                  {quickTopic}
                </Button>
              ))}
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Additional Details (Optional)</label>
              <Textarea
                placeholder="Describe your experience level, specific goals, or any preferences..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full"
                rows={3}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Difficulty Level</label>
              <Select value={difficulty} onValueChange={setDifficulty}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {topic && (
            <div className="space-y-3">
              <label className="text-sm font-medium">Recommended AI Provider</label>
              <div className="grid gap-3">
                {aiProviders.map((provider) => {
                  const Icon = provider.icon
                  const isRecommended = selectedAI === provider.id
                  return (
                    <div
                      key={provider.id}
                      className={`p-3 rounded-lg border transition-all ${
                        isRecommended 
                          ? 'border-primary bg-primary/5 shadow-glow' 
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-lg ${provider.color}`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div>
                            <div className="font-medium">{provider.name}</div>
                            <div className="text-sm text-muted-foreground">{provider.description}</div>
                          </div>
                        </div>
                        {isRecommended && (
                          <Badge variant="default" className="bg-primary">
                            Recommended
                          </Badge>
                        )}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {provider.topics.map((topicTag) => (
                          <Badge key={topicTag} variant="secondary" className="text-xs">
                            {topicTag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          <Button
            onClick={generateRoadmap}
            disabled={!topic.trim() || isGenerating}
            className="w-full h-12 text-base"
            size="lg"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Roadmap...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Learning Roadmap
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}