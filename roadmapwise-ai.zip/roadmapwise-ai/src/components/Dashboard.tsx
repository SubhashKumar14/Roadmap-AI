import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, Target, Trophy, TrendingUp, Flame, Star, BookOpen, CheckCircle } from "lucide-react"

interface DashboardProps {
  userStats: {
    streak: number
    totalCompleted: number
    level: number
    experiencePoints: number
    activeLearningDays: number[]
    weeklyGoal: number
    weeklyProgress: number
  }
  roadmaps: any[]
}

export function Dashboard({ userStats, roadmaps }: DashboardProps) {
  // Generate calendar data for the last year (365 days) - LeetCode style
  const generateCalendarData = () => {
    const days = []
    const today = new Date()
    const oneYearAgo = new Date(today)
    oneYearAgo.setFullYear(today.getFullYear() - 1)
    
    // Start from the beginning of the week that contains one year ago
    const startDate = new Date(oneYearAgo)
    startDate.setDate(startDate.getDate() - startDate.getDay())
    
    // Generate approximately 53 weeks worth of days
    for (let i = 0; i < 371; i++) {
      const date = new Date(startDate)
      date.setDate(date.getDate() + i)
      
      if (date > today) break
      
      const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000)
      const hasActivity = userStats.activeLearningDays.includes(dayOfYear)
      
      // Simulate varying activity levels based on completed tasks
      const activityLevel = hasActivity ? Math.floor(Math.random() * 4) + 1 : 0
      
      days.push({
        date: date.toISOString().split('T')[0],
        hasActivity,
        activityLevel,
        day: date.getDate(),
        month: date.getMonth(),
        weekday: date.getDay(),
        tasksCompleted: hasActivity ? Math.floor(Math.random() * 5) + 1 : 0
      })
    }
    
    return days
  }

  const calendarData = generateCalendarData()
  const activeRoadmaps = roadmaps.filter(r => r.progress < 100)
  const completedRoadmaps = roadmaps.filter(r => r.progress === 100)

  const achievements = [
    { id: 1, title: "First Steps", description: "Complete your first task", icon: Star, earned: true },
    { id: 2, title: "Week Warrior", description: "7-day learning streak", icon: Flame, earned: userStats.streak >= 7 },
    { id: 3, title: "Module Master", description: "Complete 5 modules", icon: Target, earned: userStats.totalCompleted >= 5 },
    { id: 4, title: "Road Runner", description: "Complete a full roadmap", icon: Trophy, earned: completedRoadmaps.length > 0 },
  ]

  const getActivityLevel = (activityLevel: number) => {
    switch (activityLevel) {
      case 0: return "bg-muted hover:bg-muted/80"
      case 1: return "bg-success/20 hover:bg-success/30"
      case 2: return "bg-success/40 hover:bg-success/50"
      case 3: return "bg-success/60 hover:bg-success/70"
      case 4: return "bg-success hover:bg-success/90"
      default: return "bg-muted"
    }
  }

  const getActivityText = (day: any) => {
    if (!day.hasActivity) return 'No contributions'
    if (day.tasksCompleted === 1) return '1 task'
    return `${day.tasksCompleted} tasks`
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Flame className="h-5 w-5 text-accent" />
              <div className="space-y-1">
                <p className="text-2xl font-bold">{userStats.streak}</p>
                <p className="text-xs text-muted-foreground">Day Streak</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-success" />
              <div className="space-y-1">
                <p className="text-2xl font-bold">{userStats.totalCompleted}</p>
                <p className="text-xs text-muted-foreground">Tasks Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <div className="space-y-1">
                <p className="text-2xl font-bold">{userStats.level}</p>
                <p className="text-xs text-muted-foreground">Level</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-secondary" />
              <div className="space-y-1">
                <p className="text-2xl font-bold">{activeRoadmaps.length}</p>
                <p className="text-xs text-muted-foreground">Active Roadmaps</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Weekly Goal</span>
          </CardTitle>
          <CardDescription>
            Complete {userStats.weeklyGoal} tasks this week
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>{userStats.weeklyProgress} / {userStats.weeklyGoal} tasks</span>
              <span>{Math.round((userStats.weeklyProgress / userStats.weeklyGoal) * 100)}%</span>
            </div>
            <Progress value={(userStats.weeklyProgress / userStats.weeklyGoal) * 100} />
          </div>
        </CardContent>
      </Card>

      {/* Activity Calendar */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CalendarDays className="h-5 w-5" />
            <span>Learning Activity</span>
          </CardTitle>
          <CardDescription>
            Your learning activity over the past year
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Calendar Grid */}
            <div className="overflow-x-auto">
              <div className="grid grid-cols-53 gap-1 min-w-[700px]">
                {calendarData.map((day, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-sm ${getActivityLevel(day.activityLevel)} transition-all cursor-pointer border border-transparent hover:border-primary/50`}
                    title={`${day.date}: ${getActivityText(day)}`}
                  />
                ))}
              </div>
            </div>
            
            {/* Activity Statistics */}
            <div className="flex items-center justify-between text-sm">
              <div className="text-muted-foreground">
                {userStats.totalCompleted} tasks completed in the past year
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-xs text-muted-foreground">Less</span>
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 rounded-sm bg-muted"></div>
                  <div className="w-3 h-3 rounded-sm bg-success/20"></div>
                  <div className="w-3 h-3 rounded-sm bg-success/40"></div>
                  <div className="w-3 h-3 rounded-sm bg-success/60"></div>
                  <div className="w-3 h-3 rounded-sm bg-success"></div>
                </div>
                <span className="text-xs text-muted-foreground">More</span>
              </div>
            </div>
            
            {/* Learning Streak */}
            <div className="flex items-center justify-between pt-2 border-t">
              <div className="flex items-center space-x-2">
                <Flame className="h-4 w-4 text-accent" />
                <span className="text-sm">Current streak</span>
              </div>
              <div className="text-sm font-semibold">{userStats.streak} days</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5" />
            <span>Achievements</span>
          </CardTitle>
          <CardDescription>
            Your learning milestones and badges
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement) => {
              const Icon = achievement.icon
              return (
                <div
                  key={achievement.id}
                  className={`p-4 rounded-lg border transition-all ${
                    achievement.earned 
                      ? 'border-primary bg-primary/5 shadow-glow' 
                      : 'border-border opacity-50'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      achievement.earned 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="font-medium">{achievement.title}</div>
                      <div className="text-sm text-muted-foreground">{achievement.description}</div>
                    </div>
                    {achievement.earned && (
                      <Badge className="ml-auto">Earned</Badge>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Active Roadmaps */}
      {activeRoadmaps.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Continue Learning</CardTitle>
            <CardDescription>
              Pick up where you left off
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeRoadmaps.slice(0, 3).map((roadmap) => (
                <div key={roadmap.id} className="p-4 border rounded-lg hover:border-primary/50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">{roadmap.title}</h3>
                    <Badge variant="secondary">{Math.round(roadmap.progress)}%</Badge>
                  </div>
                  <Progress value={roadmap.progress} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}