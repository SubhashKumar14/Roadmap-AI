import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { 
  User, Key, Brain, Globe, Palette, Save, Eye, EyeOff, 
  Trophy, Target, Flame, Star, MapPin, Github, Twitter, Calendar,
  TrendingUp, Award, CheckCircle, Clock
} from "lucide-react"
import { Switch } from "@/components/ui/switch"

interface ProfileProps {
  userProfile: {
    name: string
    email: string
    bio: string
    avatar?: string
    location?: string
    githubUsername?: string
    twitterUsername?: string
    joinDate: string
    rank: number
    learningGoals: string[]
    preferences: {
      emailNotifications: boolean
      weeklyDigest: boolean
      achievementAlerts: boolean
    }
  }
  userStats: {
    streak: number
    totalCompleted: number
    level: number
    experiencePoints: number
    activeLearningDays: number[]
    weeklyGoal: number
    weeklyProgress: number
    problemsSolved: {
      easy: number
      medium: number
      hard: number
      total: number
    }
    globalRanking?: number
    attendedContests?: number
  }
  achievements: Array<{
    id: number
    title: string
    description: string
    icon: any
    earned: boolean
    earnedDate?: string
    category: 'streak' | 'completion' | 'skill' | 'special'
  }>
  apiKeys: {
    openai: string
    gemini: string
    perplexity: string
  }
  onProfileUpdate: (profile: any) => void
  onApiKeyUpdate: (provider: string, key: string) => void
}

export function Profile({ userProfile, userStats, achievements, apiKeys, onProfileUpdate, onApiKeyUpdate }: ProfileProps) {
  const [profile, setProfile] = useState(userProfile)
  const [keys, setKeys] = useState(apiKeys)
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({
    openai: false,
    gemini: false,
    perplexity: false
  })
  const [newGoal, setNewGoal] = useState("")

  const handleSaveProfile = () => {
    onProfileUpdate(profile)
  }

  const handleApiKeyChange = (provider: string, value: string) => {
    setKeys(prev => ({ ...prev, [provider]: value }))
    onApiKeyUpdate(provider, value)
  }

  const addGoal = () => {
    if (newGoal.trim()) {
      setProfile(prev => ({
        ...prev,
        learningGoals: [...prev.learningGoals, newGoal.trim()]
      }))
      setNewGoal("")
    }
  }

  const removeGoal = (index: number) => {
    setProfile(prev => ({
      ...prev,
      learningGoals: prev.learningGoals.filter((_, i) => i !== index)
    }))
  }

  const apiProviders = [
    {
      id: 'openai',
      name: 'OpenAI API Key',
      description: 'For GPT-4 powered roadmaps and technical content',
      icon: Brain,
      placeholder: 'sk-...',
      helpUrl: 'https://platform.openai.com/api-keys'
    },
    {
      id: 'gemini',
      name: 'Google Gemini API Key',
      description: 'For creative and multimedia learning paths',
      icon: Palette,
      placeholder: 'AIza...',
      helpUrl: 'https://makersuite.google.com/app/apikey'
    },
    {
      id: 'perplexity',
      name: 'Perplexity API Key',
      description: 'For up-to-date research and trending topics',
      icon: Globe,
      placeholder: 'pplx-...',
      helpUrl: 'https://docs.perplexity.ai/docs/getting-started'
    }
  ]

  const maskApiKey = (key: string) => {
    if (!key) return ''
    if (key.length <= 8) return '●'.repeat(key.length)
    return key.substring(0, 4) + '●'.repeat(key.length - 8) + key.substring(key.length - 4)
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase()
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'hsl(var(--success))'
      case 'medium': return 'hsl(var(--warning))'
      case 'hard': return 'hsl(var(--destructive))'
      default: return 'hsl(var(--muted))'
    }
  }

  const earnedAchievements = achievements.filter(a => a.earned)
  const recentAchievements = earnedAchievements.slice(0, 4)

  return (
    <div className="space-y-6">
      {/* LeetCode-style Profile Header */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Profile Section */}
        <div className="lg:col-span-4 space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center space-y-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={profile.avatar} alt={profile.name} />
                  <AvatarFallback className="text-xl font-bold bg-primary text-primary-foreground">
                    {getInitials(profile.name || 'User')}
                  </AvatarFallback>
                </Avatar>
                
                <div className="text-center space-y-1">
                  <h2 className="text-2xl font-bold">{profile.name || 'Student'}</h2>
                  <p className="text-muted-foreground">@{profile.email?.split('@')[0] || 'username'}</p>
                  {userProfile.rank && (
                    <Badge variant="secondary" className="mt-2">
                      Rank {userProfile.rank.toLocaleString()}
                    </Badge>
                  )}
                </div>

                {profile.bio && (
                  <p className="text-sm text-center text-muted-foreground">
                    {profile.bio}
                  </p>
                )}

                <div className="w-full space-y-3 text-sm">
                  {profile.location && (
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{profile.location}</span>
                    </div>
                  )}
                  
                  {profile.githubUsername && (
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Github className="h-4 w-4" />
                      <span>{profile.githubUsername}</span>
                    </div>
                  )}
                  
                  {profile.twitterUsername && (
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Twitter className="h-4 w-4" />
                      <span>@{profile.twitterUsername}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>Joined {userProfile.joinDate}</span>
                  </div>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Community Stats */}
              <div className="space-y-3">
                <h3 className="font-semibold">Community Stats</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span>Streak</span>
                    </div>
                    <span className="font-medium">{userStats.streak}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 rounded-full bg-success"></div>
                      <span>Solutions</span>
                    </div>
                    <span className="font-medium">{userStats.totalCompleted}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 rounded-full bg-warning"></div>
                      <span>Reputation</span>
                    </div>
                    <span className="font-medium">{userStats.experiencePoints}</span>
                  </div>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Learning Goals */}
              <div className="space-y-3">
                <h3 className="font-semibold">Learning Goals</h3>
                <div className="flex flex-wrap gap-1">
                  {profile.learningGoals.map((goal, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {goal}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Stats Section */}
        <div className="lg:col-span-8 space-y-6">
          {/* Contest Rating & Rankings */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-sm text-muted-foreground">Contest Rating</div>
                <div className="text-2xl font-bold">{userStats.level * 324}</div>
                <div className="text-xs text-muted-foreground">Level {userStats.level}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-sm text-muted-foreground">Global Ranking</div>
                <div className="text-2xl font-bold">{userStats.globalRanking?.toLocaleString() || 'N/A'}</div>
                <div className="text-xs text-muted-foreground">Top 20.14%</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-sm text-muted-foreground">Attended</div>
                <div className="text-2xl font-bold">{userStats.attendedContests || 15}</div>
                <div className="text-xs text-muted-foreground">Contests</div>
              </CardContent>
            </Card>
          </div>

          {/* Problems Solved Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Problems Solved</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center mb-6">
                <div className="relative w-48 h-48">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="hsl(var(--muted))"
                      strokeWidth="8"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="hsl(var(--success))"
                      strokeWidth="8"
                      strokeDasharray={`${(userStats.problemsSolved.easy / 100) * 251.2} 251.2`}
                      strokeLinecap="round"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="30"
                      fill="none"
                      stroke="hsl(var(--warning))"
                      strokeWidth="8"
                      strokeDasharray={`${(userStats.problemsSolved.medium / 100) * 188.4} 188.4`}
                      strokeLinecap="round"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="20"
                      fill="none"
                      stroke="hsl(var(--destructive))"
                      strokeWidth="8"
                      strokeDasharray={`${(userStats.problemsSolved.hard / 50) * 125.6} 125.6`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="text-3xl font-bold">{userStats.problemsSolved.total}</div>
                    <div className="text-sm text-muted-foreground">Solved</div>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-lg font-semibold" style={{ color: getDifficultyColor('easy') }}>
                    {userStats.problemsSolved.easy}
                  </div>
                  <div className="text-sm text-muted-foreground">Easy</div>
                </div>
                <div>
                  <div className="text-lg font-semibold" style={{ color: getDifficultyColor('medium') }}>
                    {userStats.problemsSolved.medium}
                  </div>
                  <div className="text-sm text-muted-foreground">Medium</div>
                </div>
                <div>
                  <div className="text-lg font-semibold" style={{ color: getDifficultyColor('hard') }}>
                    {userStats.problemsSolved.hard}
                  </div>
                  <div className="text-sm text-muted-foreground">Hard</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Badges Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Badges</span>
                <Badge variant="secondary">{earnedAchievements.length}</Badge>
              </CardTitle>
              <CardDescription>
                Your learning achievements and milestones
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {recentAchievements.map((achievement) => {
                  const Icon = achievement.icon
                  return (
                    <div key={achievement.id} className="text-center p-4 border rounded-lg hover:border-primary/50 transition-colors">
                      <div className="mb-2 flex justify-center">
                        <div className="p-3 rounded-full bg-primary/10">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                      </div>
                      <div className="text-sm font-medium">{achievement.title}</div>
                      <div className="text-xs text-muted-foreground mt-1">{achievement.description}</div>
                      {achievement.earnedDate && (
                        <div className="text-xs text-muted-foreground mt-1">
                          {achievement.earnedDate}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
              
              {earnedAchievements.length > 4 && (
                <div className="mt-4 text-center">
                  <Button variant="outline" size="sm">
                    View All Badges ({earnedAchievements.length})
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Edit Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>Edit Profile</span>
          </CardTitle>
          <CardDescription>
            Manage your personal information and learning preferences
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={profile.name}
                onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter your full name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={profile.email}
                onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
                placeholder="your.email@example.com"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={profile.location || ''}
                onChange={(e) => setProfile(prev => ({ ...prev, location: e.target.value }))}
                placeholder="City, Country"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="github">GitHub Username</Label>
              <Input
                id="github"
                value={profile.githubUsername || ''}
                onChange={(e) => setProfile(prev => ({ ...prev, githubUsername: e.target.value }))}
                placeholder="username"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              value={profile.bio}
              onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
              placeholder="Tell us about yourself and your learning journey..."
              rows={3}
            />
          </div>

          <div className="space-y-4">
            <Label>Learning Goals</Label>
            <div className="flex flex-wrap gap-2">
              {profile.learningGoals.map((goal, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                  onClick={() => removeGoal(index)}
                >
                  {goal} ×
                </Badge>
              ))}
            </div>
            <div className="flex space-x-2">
              <Input
                value={newGoal}
                onChange={(e) => setNewGoal(e.target.value)}
                placeholder="Add a learning goal..."
                onKeyPress={(e) => e.key === 'Enter' && addGoal()}
              />
              <Button onClick={addGoal} variant="outline">Add</Button>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <Label>Notification Preferences</Label>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive updates about your progress</p>
                </div>
                <Switch
                  checked={profile.preferences.emailNotifications}
                  onCheckedChange={(checked) => 
                    setProfile(prev => ({
                      ...prev,
                      preferences: { ...prev.preferences, emailNotifications: checked }
                    }))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Weekly Digest</Label>
                  <p className="text-sm text-muted-foreground">Get a summary of your weekly progress</p>
                </div>
                <Switch
                  checked={profile.preferences.weeklyDigest}
                  onCheckedChange={(checked) => 
                    setProfile(prev => ({
                      ...prev,
                      preferences: { ...prev.preferences, weeklyDigest: checked }
                    }))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Achievement Alerts</Label>
                  <p className="text-sm text-muted-foreground">Get notified when you earn badges</p>
                </div>
                <Switch
                  checked={profile.preferences.achievementAlerts}
                  onCheckedChange={(checked) => 
                    setProfile(prev => ({
                      ...prev,
                      preferences: { ...prev.preferences, achievementAlerts: checked }
                    }))
                  }
                />
              </div>
            </div>
          </div>

          <Button onClick={handleSaveProfile} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Save Profile
          </Button>
        </CardContent>
      </Card>

      {/* API Keys Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Key className="h-5 w-5" />
            <span>API Keys</span>
          </CardTitle>
          <CardDescription>
            Configure your AI provider API keys for unlimited roadmap generation
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-4 bg-info/10 border border-info/20 rounded-lg">
            <h4 className="font-medium text-info mb-2">Why do I need API keys?</h4>
            <p className="text-sm text-muted-foreground">
              API keys allow unlimited roadmap generation by connecting directly to AI providers. 
              Without them, you're limited to a few free generations per day. Your keys are stored 
              securely and only used for your requests.
            </p>
          </div>

          {apiProviders.map((provider) => {
            const Icon = provider.icon
            const isVisible = showKeys[provider.id]
            const hasKey = Boolean(keys[provider.id as keyof typeof keys])

            return (
              <div key={provider.id} className="space-y-3 p-4 border rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <Label className="font-medium">{provider.name}</Label>
                      <p className="text-sm text-muted-foreground">{provider.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {hasKey && (
                      <Badge variant={hasKey ? "default" : "secondary"}>
                        {hasKey ? "Configured" : "Not Set"}
                      </Badge>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowKeys(prev => ({ ...prev, [provider.id]: !prev[provider.id] }))}
                    >
                      {isVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Input
                    type={isVisible ? "text" : "password"}
                    value={isVisible ? keys[provider.id as keyof typeof keys] : maskApiKey(keys[provider.id as keyof typeof keys])}
                    onChange={(e) => handleApiKeyChange(provider.id, e.target.value)}
                    placeholder={provider.placeholder}
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(provider.helpUrl, '_blank')}
                  >
                    Get Key
                  </Button>
                </div>
              </div>
            )
          })}

          <div className="p-4 bg-warning/10 border border-warning/20 rounded-lg">
            <h4 className="font-medium text-warning mb-2">Security Notice</h4>
            <p className="text-sm text-muted-foreground">
              Your API keys are stored locally in your browser and are never shared with third parties. 
              For production use, consider setting up backend API key management.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}